package com.example.fitlife

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.fitlife.DataBase.SQLiteUsuarios

class Detallesplan : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detallesplan)

        val planId = intent.getIntExtra("planId", -1)
        val planTitle = findViewById<TextView>(R.id.TituloDieta)
        val planContent = findViewById<TextView>(R.id.planContent)

        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val cursor = bd.rawQuery("SELECT nombre, contenido FROM PlanesEntrenamiento WHERE id=?", arrayOf(planId.toString()))

        if (cursor.moveToFirst()) {
            val nombrePlan = cursor.getString(0)
            val contenidoPlan = cursor.getString(1)

            planTitle.text = nombrePlan

            planContent.text = contenidoPlan
        }

        cursor.close()


    }
}
