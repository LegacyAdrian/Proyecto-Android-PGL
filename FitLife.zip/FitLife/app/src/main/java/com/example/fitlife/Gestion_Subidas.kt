package com.example.fitlife

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios
import com.example.fitlife.Perfil_Usuario
import com.example.fitlife.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Gestion_Subidas : AppCompatActivity() {

    // Inicializar botones y contenedores para mostrar los datos
    private lateinit var contenedorProgresos: LinearLayout
    private lateinit var contenedorDietas: LinearLayout
    private lateinit var contenedorEntrenamientos: LinearLayout
    private var identificadorUsuario: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_gestion_subidas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Contenedores
        val bundle = intent.extras
        identificadorUsuario = bundle?.getInt("Identificador")
        contenedorProgresos = findViewById(R.id.contenedorProgresos)
        contenedorDietas = findViewById(R.id.contenedorDietas)
        contenedorEntrenamientos = findViewById(R.id.contenedorEntrenamientos)

        cargarDatos()
        val volver = findViewById<Button>(R.id.VolverInicio3)
        volver.setOnClickListener {
            val cambio = Intent(this, Perfil_Usuario::class.java)
            cambio.putExtra("Identificador", identificadorUsuario)
            startActivity(cambio)
        }
    }

    // Cargar datos de progresos, dietas y entrenamientos
    @SuppressLint("Range")
    private fun cargarDatos() {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.readableDatabase

        // Progresos
        val cursorProgreso = db.rawQuery("SELECT id, fecha FROM Progreso WHERE usuario_id = ?", arrayOf(identificadorUsuario.toString()))
        while (cursorProgreso.moveToNext()) {
            val idProgreso = cursorProgreso.getInt(cursorProgreso.getColumnIndex("id"))
            val fechaProgreso = cursorProgreso.getString(cursorProgreso.getColumnIndex("fecha"))
            val progressView = crearVistaDeProgreso(idProgreso, fechaProgreso)
            contenedorProgresos.addView(progressView)
        }
        cursorProgreso.close()

        // Dietas
        val cursorDieta = db.rawQuery("SELECT id, nombre FROM Dietas WHERE creador_id = ?", arrayOf(identificadorUsuario.toString()))
        while (cursorDieta.moveToNext()) {
            val idDieta = cursorDieta.getInt(cursorDieta.getColumnIndex("id"))
            val nombreDieta = cursorDieta.getString(cursorDieta.getColumnIndex("nombre"))
            val dietaView = crearVistaDeDieta(idDieta, nombreDieta)
            contenedorDietas.addView(dietaView)
        }
        cursorDieta.close()

        // Entrenamientos
        val cursorEntrenamiento = db.rawQuery("SELECT id, nombre FROM PlanesEntrenamiento WHERE creador_id = ?", arrayOf(identificadorUsuario.toString()))
        while (cursorEntrenamiento.moveToNext()) {
            val idEntrenamiento = cursorEntrenamiento.getInt(cursorEntrenamiento.getColumnIndex("id"))
            val nombreEntrenamiento = cursorEntrenamiento.getString(cursorEntrenamiento.getColumnIndex("nombre"))
            val entrenamientoView = crearVistaDeEntrenamiento(idEntrenamiento, nombreEntrenamiento)
            contenedorEntrenamientos.addView(entrenamientoView)
        }
        cursorEntrenamiento.close()
    }

    // Crear vista para mostrar un progreso con la fecha
    private fun crearVistaDeProgreso(id: Int, fecha: String): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL
        val textView = TextView(this)
        textView.text = fecha  // Mostrar la fecha en lugar de la descripción
        val btnEliminar = Button(this)
        btnEliminar.text = "Eliminar"
        btnEliminar.setBackgroundColor(Color.RED)
        btnEliminar.setTextColor(Color.WHITE)
        btnEliminar.setOnClickListener { mostrarAlerta("¿Seguro que deseas eliminar este progreso?", "Progreso", id) }
        layout.addView(textView)
        layout.addView(btnEliminar)
        return layout
    }

    // Crear vista para mostrar una dieta con un botón para eliminar
    private fun crearVistaDeDieta(id: Int, nombre: String): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL
        val textView = TextView(this)
        textView.text = nombre
        val btnEliminar = Button(this)
        btnEliminar.text = "Eliminar"
        btnEliminar.setBackgroundColor(Color.RED)
        btnEliminar.setTextColor(Color.WHITE)
        btnEliminar.setOnClickListener {
            mostrarAlerta("¿Seguro que deseas eliminar esta dieta?", "Dieta", id)
        }
        layout.addView(textView)
        layout.addView(btnEliminar)

        return layout
    }

    // Crear vista para mostrar un entrenamiento con un botón para eliminar
    private fun crearVistaDeEntrenamiento(id: Int, nombre: String): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL
        val textView = TextView(this)
        textView.text = nombre
        val btnEliminar = Button(this)
        btnEliminar.text = "Eliminar"
        btnEliminar.setBackgroundColor(Color.RED)
        btnEliminar.setTextColor(Color.WHITE)
        btnEliminar.setOnClickListener { mostrarAlerta("¿Seguro que deseas eliminar este entrenamiento?", "Entrenamiento", id) }
        layout.addView(textView)
        layout.addView(btnEliminar)
        return layout
    }

    // Mostrar alerta de confirmación
    private fun mostrarAlerta(mensaje: String, tipo: String, id: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(mensaje)
            .setPositiveButton("Sí") { dialog, which ->
                when (tipo) {
                    "Progreso" -> eliminarProgreso(id)
                    "Dieta" -> eliminarDieta(id)
                    "Entrenamiento" -> eliminarEntrenamiento(id)
                }
            }
            .setNegativeButton("No") { dialog, which -> dialog.dismiss() }
        builder.create().show()
    }

    // Eliminar progreso
    private fun eliminarProgreso(id: Int) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.writableDatabase
        val sql = "DELETE FROM Progreso WHERE id = ? AND usuario_id = ?"
        db.execSQL(sql, arrayOf(id.toString(), identificadorUsuario.toString()))
        actualizarVista()
    }

    // Eliminar dieta
    private fun eliminarDieta(id: Int) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.writableDatabase
        val sql = "DELETE FROM Dietas WHERE id = ? AND creador_id = ?"
        db.execSQL(sql, arrayOf(id.toString(), identificadorUsuario.toString()))
        actualizarVista()
    }

    // Eliminar entrenamiento
    private fun eliminarEntrenamiento(id: Int) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.writableDatabase
        val sql = "DELETE FROM PlanesEntrenamiento WHERE id = ? AND creador_id = ?"
        db.execSQL(sql, arrayOf(id.toString(), identificadorUsuario.toString()))
        actualizarVista()
    }

    // Actualizar la vista después de eliminar un registro
    private fun actualizarVista() {
        // Limpiar los contenedores
        contenedorProgresos.removeAllViews()
        contenedorDietas.removeAllViews()
        contenedorEntrenamientos.removeAllViews()

        // Recargar los datos
        cargarDatos()
    }
}
