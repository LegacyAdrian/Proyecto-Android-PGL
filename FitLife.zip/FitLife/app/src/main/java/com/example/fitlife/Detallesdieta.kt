package com.example.fitlife

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Detallesdieta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detallesdieta)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val DietaId = intent.getIntExtra("dietaId", -1)
        val TituloDieta = findViewById<TextView>(R.id.TituloDieta)
        val DietaContent = findViewById<TextView>(R.id.ContenidoDieta)

        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val cursor = bd.rawQuery("SELECT nombre, contenido FROM Dietas WHERE id=?", arrayOf(DietaId.toString()))

        if (cursor.moveToFirst()) {
            val nombreDieta = cursor.getString(0)
            val ContenidoDieta = cursor.getString(1)

            TituloDieta.text = nombreDieta

            DietaContent.text = ContenidoDieta
        }

        cursor.close()
    }
}