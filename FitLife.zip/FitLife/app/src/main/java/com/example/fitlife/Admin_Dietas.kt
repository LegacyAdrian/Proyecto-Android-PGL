package com.example.fitlife

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Admin_Dietas : AppCompatActivity() {

    // Inicializar contenedor donde se mostrarán las dietas
    private lateinit var contenedorDietas: LinearLayout
    private var identificadorUsuario: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_admin_dietas)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Obtener el identificador del usuario
        val bundle = intent.extras
        identificadorUsuario = bundle?.getInt("Identificador")

        // Inicializar contenedor
        contenedorDietas = findViewById(R.id.contenedorDietas)

        // Cargar los datos de las dietas
        cargarDatos()

        // Botón para volver a la pantalla anterior
        val volverBtn: Button = findViewById(R.id.btnVolverAPerfil3)
        volverBtn.setOnClickListener {
            val cambio = Intent(this,Perfil_Usuario::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
    }

    // Cargar las dietas según el adminMode
    @SuppressLint("Range")
    private fun cargarDatos() {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.readableDatabase

        // Consulta para obtener el adminmode del usuario actual
        val cursorUsuario = db.rawQuery("SELECT adminmode FROM Registro WHERE id = ?", arrayOf(identificadorUsuario.toString()))
        cursorUsuario.moveToFirst()
        val adminMode = cursorUsuario.getInt(cursorUsuario.getColumnIndex("adminmode"))
        cursorUsuario.close()

        // Consulta para obtener las dietas según el adminMode
        var sqlQuery = ""
        when (adminMode) {
            1 -> {
                // Admins: Verán solo las dietas de usuarios con adminMode 0
                sqlQuery = "SELECT Dietas.id, Dietas.nombre, Registro.usuario " +
                        "FROM Dietas INNER JOIN Registro ON Dietas.creador_id = Registro.id " +
                        "WHERE Dietas.creador_id != ? AND Registro.adminmode = 0"
            }
            2 -> {
                // Propietarios: Verán dietas de adminMode 0 y adminMode 1
                sqlQuery = "SELECT Dietas.id, Dietas.nombre, Registro.usuario " +
                        "FROM Dietas INNER JOIN Registro ON Dietas.creador_id = Registro.id " +
                        "WHERE Dietas.creador_id != ? AND (Registro.adminmode = 0 OR Registro.adminmode = 1)"
            }
            else -> {
                return
            }
        }

        // Ejecutar la consulta para obtener las dietas
        val cursorDieta = db.rawQuery(sqlQuery, arrayOf(identificadorUsuario.toString()))
        while (cursorDieta.moveToNext()) {
            val idDieta = cursorDieta.getInt(cursorDieta.getColumnIndex("id"))
            val nombreDieta = cursorDieta.getString(cursorDieta.getColumnIndex("nombre"))
            val nombreCreador = cursorDieta.getString(cursorDieta.getColumnIndex("usuario"))
            val dietaView = crearVistaDeDieta(idDieta, nombreDieta, nombreCreador)
            contenedorDietas.addView(dietaView)
        }
        cursorDieta.close()
    }

    // Crear vista para mostrar una dieta con un botón para eliminar
    private fun crearVistaDeDieta(id: Int, nombre: String, creador: String): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL

        val textView = TextView(this)
        textView.text = "$nombre ($creador)"

        val btnEliminar = Button(this)
        btnEliminar.text = "Eliminar"
        btnEliminar.setBackgroundColor(resources.getColor(android.R.color.holo_red_dark)) // Rojo
        btnEliminar.setTextColor(resources.getColor(android.R.color.white)) // Blanco
        btnEliminar.setOnClickListener {
            mostrarAlerta("¿Seguro que deseas eliminar esta dieta?", "Dieta", id)
        }

        layout.addView(textView)
        layout.addView(btnEliminar)
        return layout
    }

    // Mostrar alerta de confirmación
    private fun mostrarAlerta(mensaje: String, tipo: String, id: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(mensaje)
            .setPositiveButton("Sí") { dialog, which ->
                when (tipo) {
                    "Dieta" -> eliminarDieta(id)
                }
            }
            .setNegativeButton("No") { dialog, which -> dialog.dismiss() }
        builder.create().show()
    }

    // Eliminar dieta
    private fun eliminarDieta(id: Int) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.writableDatabase
        val sql = "DELETE FROM Dietas WHERE id = ? AND creador_id != ?"
        db.execSQL(sql, arrayOf(id.toString(), identificadorUsuario.toString()))
        actualizarVista()
    }

    // Actualizar la vista después de eliminar una dieta
    private fun actualizarVista() {
        // Limpiar el contenedor
        contenedorDietas.removeAllViews()

        // Recargar los datos
        cargarDatos()
    }
}
