package com.example.fitlife.DataBase

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SQLiteUsuarios(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context, "usuarios.db", factory, version) {
    override fun onCreate(db: SQLiteDatabase?) {
        //Para la Tabla Registro

        db?.execSQL("CREATE TABLE Registro (id INTEGER PRIMARY KEY AUTOINCREMENT, usuario text, correo text,password text,adminmode int)")
        //Para la Tabla Información

        db?.execSQL("CREATE TABLE Informacion (id INTEGER PRIMARY KEY AUTOINCREMENT,usuario_id INTEGER ,nombre TEXT, " +
                "peso REAL, genero text,altura REAL, edad INTEGER, FOREIGN KEY(usuario_id) REFERENCES registro(id))")
        //Para la Tabla Progreso

        db?.execSQL("CREATE TABLE Progreso(id INTEGER PRIMARY KEY AUTOINCREMENT, usuario_id INTEGER, fecha DATE, descripcion text," +
                " anotacion text,Objetivo text,FOREIGN KEY(usuario_id) REFERENCES registro(id))")
        //Para la tabla Entrenamientos

        db?.execSQL("CREATE TABLE PlanesEntrenamiento (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre text, contenido text,imc REAL,creador_id INTEGER ,FOREIGN KEY(creador_id) REFERENCES registro(id))")
        //Para la tabla Dietas

        db?.execSQL("CREATE TABLE Dietas (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre text, contenido text, tipo text, precio REAL, creador_id INTEGER, FOREIGN KEY(creador_id) REFERENCES registro(id))")
        //Añadir de base

        val UsuarioAdmin = " Insert INTO registro (usuario,password,correo,adminmode) VALUES ('Admin','Admin','Admin@Admin.es','2')"
        db?.execSQL(UsuarioAdmin)

        val AñadirInfo = "INSERT INTO informacion (usuario_id, nombre, peso, genero, altura, edad) \n" +
                "    VALUES (1, 'Admin Supremo', 70.0, 'Masculino', 1.75, 25)"
        db?.execSQL(AñadirInfo)

        val AñadirInfo2 = "INSERT INTO PlanesEntrenamiento (nombre, contenido, imc, creador_id) \n" +
                "    VALUES ('Entrenamiento Espartano', 'Debes hacer 100 sentadillas, correr 100 kilometros y hacer 100 flexiones diarias ', 24.0, 1)"
        db?.execSQL(AñadirInfo2)
        val AñadirInfo3 = "INSERT INTO PlanesEntrenamiento (nombre, contenido, imc, creador_id) \n" +
                "    VALUES ('Entrenamiento Ruso', 'Simplemente pelea con un oso cada mañana camarada ', 20.0, 1)"
        db?.execSQL(AñadirInfo3)
        val AñadirInfo4 = "INSERT INTO PlanesEntrenamiento (nombre, contenido, imc, creador_id) \n" +
                "    VALUES ('Calistenia', 'Haz un par de fñexiones y corre todo los dias 20 kilometros ', 24.0, 1)"
        db?.execSQL(AñadirInfo4)
        val AñadirDieta = "INSERT INTO Dietas (nombre, contenido, tipo, precio, creador_id) \n" +
                "    VALUES ('Dieta Mediterranea', 'Comer alimentos frescos como frutas, verduras, legumbres, pescado, aceite de oliva," +
                " frutos secos y pan integral. Limitar el consumo de carnes rojas y productos procesados.', 'Omnivora', 50.0, 1)"
        db?.execSQL(AñadirDieta)
        val AñadirDieta2 = "INSERT INTO Dietas (nombre, contenido, tipo, precio, creador_id) \n" +
                "    VALUES ('Dieta Keto', 'La dieta cetogénica se basa en reducir drásticamente los carbohidratos y aumentar el consumo de grasas saludables para inducir un estado metabólico llamado cetosis, donde el cuerpo quema grasas en lugar de glucosa. Se enfoca en carnes, pescados, huevos, queso, " +
                "aguacate, aceite de coco y vegetales bajos en carbohidratos, mientras se evita el pan, la pasta, el arroz y el azúcar.', 'Omnivora" +
                "',120.0, 1)"
        db?.execSQL(AñadirDieta2)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val fechaActual = sdf.format(Date())

        val AñadirProgreso = "INSERT INTO Progreso(usuario_id,fecha,descripcion,anotacion,Objetivo)" +
                "VALUES(1,'$fechaActual','Hoy hice 400 sentadillas y me rompi la rodilla','Comprar mejores rodilleras','No')"
        db?.execSQL(AñadirProgreso)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("Not yet implemented")
    }
}