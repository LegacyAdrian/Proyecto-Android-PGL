package com.example.fitlife

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Pagina_inicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pagina_inicio)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Constantes
        val Icono = findViewById<ImageView>(R.id.UserIconProgreso)
        val Nombre = findViewById<TextView>(R.id.NombreUser)
        val Entrenamientos = findViewById<Button>(R.id.btnEntrenamientos);
        val Dietas = findViewById<Button>(R.id.btnDietas);
        val Progreso = findViewById<Button>(R.id.btnProgreso);
        val AñadirProgreso = findViewById<Button>(R.id.btnAddProgreso);

        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        val admin = SQLiteUsuarios(this,"usuarios.db",null,1)
        val bd = admin.writableDatabase
        val SQL = bd.rawQuery("SELECT usuario FROM Registro WHERE id=?", arrayOf(Identificador.toString()))
        if (SQL.moveToFirst()){Nombre.text= SQL.getString(0)}
        //Funcionalidad Aqui
        Icono.setOnClickListener{
            val cambio = Intent(this,Perfil_Usuario::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)

        }

        Entrenamientos.setOnClickListener {
            val cambio = Intent(this,Planes::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        Dietas.setOnClickListener {
            val cambio = Intent(this,InfoDietas::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        Progreso.setOnClickListener {
            val cambio = Intent(this,Progreso_User::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        AñadirProgreso.setOnClickListener {
            val cambio = Intent(this,Add_Progreso::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }


    }
}