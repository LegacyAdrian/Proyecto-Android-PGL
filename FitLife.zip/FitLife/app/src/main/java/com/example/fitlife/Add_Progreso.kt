package com.example.fitlife

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Add_Progreso : AppCompatActivity() {
    private lateinit var calendarViewFecha: CalendarView
    private lateinit var editTextDescripcion: EditText
    private lateinit var editTextAnotacion: EditText
    private lateinit var radioButtonSi: RadioButton
    private lateinit var radioButtonNo: RadioButton
    private lateinit var buttonAñadir: Button

    private lateinit var dbHelper: SQLiteUsuarios

    private var Identificador: Int = 0
    private var fechaSeleccionada: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_progreso)

        // Inicializar componentes
        calendarViewFecha = findViewById(R.id.calendarViewFecha)
        editTextDescripcion = findViewById(R.id.editTextDescripcion)
        editTextAnotacion = findViewById(R.id.editTextAnotacion)
        radioButtonSi = findViewById(R.id.radioButtonSi)
        radioButtonNo = findViewById(R.id.radioButtonNo)
        buttonAñadir = findViewById(R.id.buttonAñadir)

        Identificador = intent.getIntExtra("Identificador", 0)

        if (Identificador == 0) {
            Toast.makeText(this, "Usuario no válido", Toast.LENGTH_SHORT).show()
            finish()
        }

        dbHelper = SQLiteUsuarios(this, "usuarios.db", null, 1)
        calendarViewFecha.setOnDateChangeListener { _, year, month, dayOfMonth ->
            fechaSeleccionada = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
        }
        fechaSeleccionada = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(calendarViewFecha.date))
        buttonAñadir.setOnClickListener {
            saveProgress()
        }
    }

    private fun saveProgress() {
        val descripcion = editTextDescripcion.text.toString()
        val anotacion = editTextAnotacion.text.toString()
        val objetivo = if (radioButtonSi.isChecked) "Sí" else "No"

        if (descripcion.isEmpty() || anotacion.isEmpty()) {
            Toast.makeText(this, "Por favor, complete todos los campos.", Toast.LENGTH_SHORT).show()
            return
        }

        val bd = dbHelper.writableDatabase
        val campos = ContentValues().apply {
            put("usuario_id", Identificador)
            put("fecha", fechaSeleccionada)
            put("descripcion", descripcion)
            put("anotacion", anotacion)
            put("objetivo", objetivo)
        }

        val newRowId = bd.insert("Progreso", null, campos)

        if (newRowId != -1L) {
            Toast.makeText(this, "Progreso añadido con éxito.", Toast.LENGTH_SHORT).show()
            clearFields()
        } else {
            Toast.makeText(this, "Error al guardar el progreso.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearFields() {
        editTextDescripcion.setText("")
        editTextAnotacion.setText("")
        radioButtonSi.isChecked = false
        radioButtonNo.isChecked = false
    }
}






