package com.example.fitlife

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Add_Entrenamiento : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_entrenamiento)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Constantes
        val nombreEntrenamiento= findViewById<EditText>(R.id.nombreEntrenamiento)
        val contenidoEntrenamiento = findViewById<EditText>(R.id.contenidoEntrenamiento)
        val imcEntrenamiento= findViewById<EditText>(R.id.imcEntrenamiento)
        val btnCrearEntrenamiento= findViewById<Button>(R.id.btnGuardarEntrenamiento)
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        val Volver= findViewById<Button>(R.id.btnVolveraEntrenamiento)
        //Funciones
        btnCrearEntrenamiento.setOnClickListener {
        if (nombreEntrenamiento.text.toString().trim().isEmpty() ||
            contenidoEntrenamiento.text.toString().trim().isEmpty() ||
            imcEntrenamiento.text.toString().trim().isEmpty()) {
            Toast.makeText(this, "Por favor rellena todos los campos", Toast.LENGTH_SHORT).show()
            return@setOnClickListener }
            val admin = SQLiteUsuarios(this,"usuarios.db",null,1)
            val bd = admin.writableDatabase
            val comprobante = bd.rawQuery("SELECT nombre FROM PlanesEntrenamiento WHERE id=?", arrayOf(Identificador.toString()))

            if (comprobante.moveToFirst()){
                val campos = ContentValues()
                campos.put("nombre",nombreEntrenamiento.text.toString().trim())
                campos.put("contenido",contenidoEntrenamiento.text.toString().trim())
                campos.put("imc",imcEntrenamiento.text.toString().toDouble())
                campos.put("creador_id",Identificador)
                val Insertar = bd.insert("PlanesEntrenamiento",null,campos)
                bd.close()
                Toast.makeText(this, "Plan de Entrenamiento Creado con Exito", Toast.LENGTH_SHORT).show()
            }
            Volver.setOnClickListener {
                val cambio = Intent(this,Planes::class.java)
                cambio.putExtra("Identificador",Identificador)
                startActivity(cambio)
            }

        }
    }
}