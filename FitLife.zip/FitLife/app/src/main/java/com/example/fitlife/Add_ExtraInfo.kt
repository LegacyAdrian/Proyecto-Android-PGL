package com.example.fitlife

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Add_ExtraInfo : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_extra_info)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Constantes
        val usuario = findViewById<TextView>(R.id.userName)
        val nombre = findViewById<EditText>(R.id.nombrecompleto)
        val peso = findViewById<EditText>(R.id.peso)
        val genero = findViewById<EditText>(R.id.genero)
        val altura = findViewById<EditText>(R.id.altura)
        val edad = findViewById<EditText>(R.id.edad)
        val guardar = findViewById<Button>(R.id.guardarextrainfo)
        val volver = findViewById<Button>(R.id.btnVolverAPerfil2)

        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")


        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val SQL = bd.rawQuery(
            "SELECT usuario FROM Registro WHERE id=?",
            arrayOf(Identificador.toString())
        )
        if (SQL.moveToFirst()) {
            usuario.text = SQL.getString(0)
        }

        val Sentencia = bd.rawQuery(
            "SELECT * FROM Informacion WHERE usuario_id=?",
            arrayOf(Identificador.toString())
        )

        if (Sentencia.moveToFirst()) {
            // Si existen datos, cargarlos en los campos correspondientes
            nombre.setText(Sentencia.getString(2).toString())
            peso.setText(Sentencia.getDouble(3).toString())
            genero.setText(Sentencia.getString(4).toString())
            altura.setText(Sentencia.getDouble(5).toString())
            edad.setText(Sentencia.getInt(6).toString())

            guardar.setOnClickListener {
                val campos = ContentValues()
                campos.put("nombre", nombre.text.toString())
                campos.put("peso", peso.text.toString())
                campos.put("genero", genero.text.toString())
                campos.put("altura", altura.text.toString())
                campos.put("edad", edad.text.toString())
                val Guardado = bd.update(
                    "Informacion",
                    campos,
                    "usuario_id=?",
                    arrayOf(Identificador.toString())
                )

                if (Guardado == 1) {
                    Toast.makeText(this, "Cambios realizados con exito", Toast.LENGTH_SHORT).show()
                }
            }


        } else {
            guardar.setOnClickListener {
                val campos = ContentValues()
                campos.put("nombre", nombre.text.toString())
                campos.put("peso", peso.text.toString())
                campos.put("genero", genero.text.toString())
                campos.put("altura", altura.text.toString())
                campos.put("edad", edad.text.toString())
                campos.put("usuario_id", Identificador)
                val Guardado = bd.insert("Informacion", null, campos)
                Toast.makeText(this, "Cambios realizados con exito", Toast.LENGTH_SHORT).show()

            }

        }
        volver.setOnClickListener {
            val cambio = Intent(this, Perfil_Usuario::class.java)
            cambio.putExtra("Identificador", Identificador)
            startActivity(cambio)
        }
    }
}