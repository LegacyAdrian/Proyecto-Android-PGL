package com.example.fitlife

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_registro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Constantes
        val Usuario = findViewById<EditText>(R.id.UsuarioRegistro)
        val Correo = findViewById<EditText>(R.id.CorreoRegistro)
        val Contraseña = findViewById<EditText>(R.id.ContraseñaRegistro)
        val ConfirmarContraseña = findViewById<EditText>(R.id.ConfirmarContraseña)
        val Registrarse = findViewById<Button>(R.id.btnRegistrar)
        val IrLoging = findViewById<TextView>(R.id.iraloging)

        //Funciones
        Registrarse.setOnClickListener {
            if (Usuario.text.toString().trim().isEmpty()||Correo.text.toString().trim().isEmpty()||Contraseña.text.toString().trim().isEmpty()){
                Toast.makeText(this, "Por favor rellena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            else if(!Correo.text.toString().trim().contains("@")){
                Toast.makeText(this, "Inserte un correo valido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
           else if (!Contraseña.text.toString().trim().equals(ConfirmarContraseña.text.toString().trim())) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val admin = SQLiteUsuarios(this,"usuarios.db",null,1)
            val bd = admin.writableDatabase
            val comprobante = bd.rawQuery("SELECT usuario FROM Registro WHERE usuario=?", arrayOf(Usuario.text.toString().trim()))

            if (comprobante.moveToFirst()){
                Toast.makeText(this, "Error Este usuario ya esta registrado", Toast.LENGTH_SHORT).show()
                bd.close()
            } else {
                    val campos = ContentValues()
                    campos.put("usuario",Usuario.text.toString().trim())
                    campos.put("password",Contraseña.text.toString().trim())
                    campos.put("correo",Correo.text.toString())
                    campos.put("adminmode",0)

                    val Insertar = bd.insert("Registro",null,campos)
                    bd.close()
                    Toast.makeText(this, "Usuario creado con exito", Toast.LENGTH_SHORT).show()
                    val cambio = Intent(this,MainActivity::class.java)
                    startActivity(cambio)
            }
        }
        IrLoging.setOnClickListener {
            val cambio = Intent(this,MainActivity::class.java)
            startActivity(cambio)
        }
    }
}