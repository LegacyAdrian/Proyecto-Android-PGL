package com.example.fitlife

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Constantes
        val Usuario = findViewById<EditText>(R.id.UsuarioIniciar)
        val Contraseña = findViewById<EditText>(R.id.ContraseñaIniciar)
        val Iniciar = findViewById<Button>(R.id.btnIniciarSesion)
        val IraRegistro = findViewById<TextView>(R.id.iraregistro)

        //Funciones
        IraRegistro.setOnClickListener{
            val cambio = Intent(this,Registro::class.java)
            startActivity(cambio)
        }

        Iniciar.setOnClickListener{
            val admin = SQLiteUsuarios(this,"usuario.db",null,1)
            val bd = admin.writableDatabase
            val sentencia = bd.rawQuery("SELECT id,usuario,password FROM Registro WHERE usuario=? AND password=?",
                arrayOf(Usuario.text.toString().trim(),Contraseña.text.toString().trim())
            )
            if (sentencia.moveToFirst()){
                val cambio = Intent(this,Pagina_inicio::class.java)
                cambio.putExtra("Identificador",sentencia.getInt(0))
                startActivity(cambio)
            }
            else{
                Toast.makeText(this, "El usuario no existe o contraseña incorrecta", Toast.LENGTH_SHORT).show()
            }
        }

    }
}