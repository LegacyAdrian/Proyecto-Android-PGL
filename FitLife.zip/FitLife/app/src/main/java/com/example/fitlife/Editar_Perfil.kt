package com.example.fitlife

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Editar_Perfil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_editar_perfil)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Constantes
        val Nombre = findViewById<EditText>(R.id.EditarNombre)
        val Correo = findViewById<EditText>(R.id.EditarCorreo)
        val Contraseña = findViewById<EditText>(R.id.EditarContraseña)
        val Guardar = findViewById<Button>(R.id.btnGuardarCambiosPerfil)
        val Volver = findViewById<Button>(R.id.btnVolverAPerfil)
        //Bundle
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        //Añadir Datos Previos
        val admin = SQLiteUsuarios(this,"usuarios.db",null,1)
        val bd = admin.writableDatabase
        val SQL = bd.rawQuery("SELECT * FROM Registro WHERE id=?", arrayOf(Identificador.toString()))
        if (SQL.moveToFirst()){
            Nombre.setText(SQL.getString(1))
            Correo.setText(SQL.getString(2))
            Contraseña.setText(SQL.getString(3))
        }
        //Funciones Botones
        Guardar.setOnClickListener {
            val campos = ContentValues()
            campos.put("usuario",Nombre.text.toString().trim())
            campos.put("password",Contraseña.text.toString().trim())
            campos.put("correo",Correo.text.toString())
            val Guardado = bd.update("Registro",campos,"id=?", arrayOf(Identificador.toString()))
            bd.close()
            if (Guardado==1){Toast.makeText(this, "Cambios realizados con exito", Toast.LENGTH_SHORT).show()}

        }
        Volver.setOnClickListener {
            val cambio = Intent(this,Pagina_inicio::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

    }
}